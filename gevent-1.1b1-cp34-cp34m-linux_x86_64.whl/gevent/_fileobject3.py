from gevent._fileobjectposix import FileObjectPosix

__all__ = ['FileObjectPosix', ]
